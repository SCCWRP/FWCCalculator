Using this Calculator
This calculator will produce a table of aliquot volume values, a hydrograph, and, if pollutant data is provided, pollutograph(s) for the given data set of flow rate measurements and sample timestamps.
1. Download the Excel template file here and overwrite it with your data. See the Data Requirements section below.
  NOTE: a 'download.htm' file may be downloaded instead of the template Excel file if the link is clicked too soon after launching the application. This is a known issue with the 'shiny' R package which was used to develop this application. Please allow a few minutes before downloading the template.
2. Upload your data by clicking the 'Browse' button, selecting the updated Excel spreadsheet, and clicking the 'Submit' button. The calculator will generate the aliquot volume table as well as the hydrograph and pollutograph(s), depending on the uploaded data. If pollutant data is provided, the calculator will also provide the Event Mean Concentration for each of the specified pollutants.
3. Use the 'Start Time' and 'End Time' inputs to filter the data to the appropriate time range. Elapsed time in minutes is presented. The grayed-out sections of the graph will not be included in the aliquot volume and event mean concentration calculations.
4. After changing the 'Start Time' and 'End Time', click the 'Redraw Graph(s)' button to regenerate the aliquot volume table, hydrograph, and pollutograph(s), filtered to the provided times.
5. The 'Composite Vol.' input is used in the aliquot volume calculation such that the sum of the aliquot volumes will be equal to the composite volume value entered here, measured in mL.
6. The 'Flow Units of Submitted Data' input is used to label and calculate the 'Total Hydrograph Volume' output.

Data Requirements
The uploaded Excel spreadsheet must conform to the following requirements:
  * Must contain exactly two sheets, in the following order:
    - Sheet 1: flow rate measurement data
    - Sheet 2: sample collection timestamps and pollutant measurement data (where applicable)
  * The flow rate measurement data sheet (Sheet 1) must have exactly two columns:
    - Col 1: timestamps in 'mm/dd/yy hh:mm:ss' format. Date and time must be provided.
      * The 'Datetime' column in the provided template file is already in the correct format.
    - Col 2: flow rate measurements. Flow rates must be entered as L/s, gpm, or cfs.
  * The sample collection timestamps and pollutant measurement sheet (Sheet 2) may have any number of columns:
    - Col 1: timestamps when water quality samples were collected in 'mm/dd/yy hh:mm:ss' format. Date and time must be provided.
      * The 'Datetime' column in the provided template file is already in the correct format.
    - Col 2...n: pollutant concentrations, if/where available
    - Any number of pollutant columns in the second sheet are supported.
    - If you do not have pollutant data, delete the 'Pollutant' columns entirely before uploading the template. Do not delete Sheet 2.
  * The column headers are required and can be renamed as needed, but cannot be exclusively numeric characters [0-9].
  * All flow rate and pollutant measurements must be greater than zero.
  * There may not be any missing values in the spreadsheet.